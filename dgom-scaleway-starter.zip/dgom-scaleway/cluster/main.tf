terraform {
  required_version = ">= 1.6.0"
  required_providers {
    scaleway = {
      source  = "scaleway/scaleway"
      version = "~> 2.80"
    }
  }
}

provider "scaleway" {
  project_id      = var.project_id
  organization_id = var.organization_id
  region          = var.region
  zone            = var.zone
}

resource "scaleway_vpc" "dgom" {
  name = "dgom-k8s-vpc"
}

resource "scaleway_vpc_private_network" "dgom" {
  name   = "dgom-k8s-pn"
  vpc_id = scaleway_vpc.dgom.id
  ipv4_subnet {
    subnet = var.private_network_cidr
  }
}

resource "scaleway_vpc_public_gateway" "dgom" {
  name = "dgom-k8s-gateway"
  type = "VPC-GW-S"
}

resource "scaleway_vpc_gateway_network" "dgom" {
  gateway_id         = scaleway_vpc_public_gateway.dgom.id
  private_network_id = scaleway_vpc_private_network.dgom.id
  enable_masquerade  = true
  ipam_config {
    push_default_route = true
  }
}

resource "scaleway_k8s_cluster" "dgom" {
  name                        = "dgom-data"
  version                     = var.kubernetes_version
  cni                         = "cilium"
  private_network_id          = scaleway_vpc_private_network.dgom.id
  delete_additional_resources = false
  tags                        = ["dgom", "terraform"]
  depends_on                  = [scaleway_vpc_gateway_network.dgom]
}

resource "scaleway_k8s_pool" "workers" {
  cluster_id = scaleway_k8s_cluster.dgom.id
  name       = "dgom-workers"
  node_type  = var.node_type
  size       = 2
  min_size   = 2
  max_size   = 2
  autoscaling = false
  autohealing = true
  public_ip_disabled = true
}

resource "scaleway_lb_ip" "ingress" {
  zone = var.zone
}

resource "scaleway_object_bucket" "cnpg_backups" {
  name          = var.backup_bucket_name
  region        = var.region
  force_destroy = false
  lifecycle {
    prevent_destroy = true
  }
}

# These are NEW names only. Existing auth.dgom, dgom and sastudio.dgom
# stay in the old DNS management until separately migrated.
data "scaleway_domain_zone" "ccp" {
  count     = var.create_app_dns_records ? 1 : 0
  domain    = "numerique-interieur.fr"
  subdomain = "sdan-ccp"
}

resource "scaleway_domain_record" "apps" {
  for_each = var.create_app_dns_records ? toset(["keycloak", "n8n", "grist", "superset"]) : toset([])
  dns_zone = data.scaleway_domain_zone.ccp[0].id
  name     = "${each.key}.dgom"
  type     = "A"
  data     = scaleway_lb_ip.ingress.ip_address
  ttl      = 300
}

output "cluster_id" {
  value = scaleway_k8s_cluster.dgom.id
}

output "private_network_id" {
  value = scaleway_vpc_private_network.dgom.id
}

output "load_balancer_ip_id" {
  value = scaleway_lb_ip.ingress.id
}

output "load_balancer_ip" {
  value = scaleway_lb_ip.ingress.ip_address
}

output "cnpg_backup_bucket" {
  value = scaleway_object_bucket.cnpg_backups.name
}

output "service_urls" {
  value = { for app in ["keycloak", "n8n", "grist", "superset"] : app => "https://${app}.dgom.sdan-ccp.numerique-interieur.fr" }
}
