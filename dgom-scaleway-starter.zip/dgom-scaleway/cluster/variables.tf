variable "project_id" {
  description = "Scaleway project UUID containing the VPC and Kubernetes cluster."
  type        = string
}
variable "organization_id" {
  description = "Scaleway organization UUID."
  type        = string
}
variable "kubernetes_version" {
  description = "Supported Kapsule Kubernetes version confirmed in your Scaleway project."
  type        = string
}
variable "private_network_cidr" {
  description = "Candidate CIDR; check all VPC and VPN routes before apply."
  type        = string
  default     = "10.80.0.0/22"
}
variable "create_app_dns_records" {
  description = "Set by deploy.sh in its DNS phase after the ingress LB exists."
  type        = bool
  default     = false
}
variable "backup_bucket_name" {
  description = "Globally unique Scaleway Object Storage bucket name."
  type        = string
}
variable "node_type" {
  description = "Worker instance type; verify memory and cost before apply."
  type        = string
  default     = "GP1-XS"
}
variable "region" {
  type    = string
  default = "fr-par"
}
variable "zone" {
  type    = string
  default = "fr-par-1"
}
