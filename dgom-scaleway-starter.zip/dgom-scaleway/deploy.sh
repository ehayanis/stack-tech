#!/usr/bin/env bash
set -euo pipefail

project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for command_name in terraform scw kubectl helm sed; do
  command -v "$command_name" >/dev/null || { echo "Missing command: $command_name" >&2; exit 1; }
done
[[ -f "$project_root/cluster/terraform.tfvars" ]] || { echo "Copy cluster/terraform.tfvars.example to cluster/terraform.tfvars first" >&2; exit 1; }

# Use an isolated kubeconfig to avoid changing the user's active context.
kubeconfig_file="$(mktemp)"
values_file="$(mktemp)"
chmod 600 "$kubeconfig_file" "$values_file"
trap 'rm -f "$kubeconfig_file" "$values_file"' EXIT
export KUBECONFIG="$kubeconfig_file"

terraform -chdir="$project_root/cluster" init
terraform -chdir="$project_root/cluster" apply -var='create_app_dns_records=false'

cluster_id="$(terraform -chdir="$project_root/cluster" output -raw cluster_id)"
cluster_uuid="${cluster_id##*/}"
lb_ip_id="$(terraform -chdir="$project_root/cluster" output -raw load_balancer_ip_id)"
lb_ip="$(terraform -chdir="$project_root/cluster" output -raw load_balancer_ip)"
private_network_id="$(terraform -chdir="$project_root/cluster" output -raw private_network_id)"

scw k8s kubeconfig install "$cluster_uuid" region=fr-par
kubectl wait --for=condition=Ready nodes --all --timeout=15m
kubectl apply -f "$project_root/k8s/namespace-storage.yaml"

sed -e "s|REPLACE_WITH_LOAD_BALANCER_IP_ID|$lb_ip_id|g" \
    -e "s|REPLACE_WITH_PRIVATE_NETWORK_ID|$private_network_id|g" \
    "$project_root/k8s/traefik-values.yaml.example" > "$values_file"
helm repo add traefik https://traefik.github.io/charts --force-update
helm repo update traefik
helm upgrade --install traefik traefik/traefik \
  --version 41.6.0 --namespace ingress-system --create-namespace \
  --values "$values_file" --wait --timeout 15m

for attempt in {1..60}; do
  assigned_ip="$(kubectl -n ingress-system get service traefik -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || true)"
  [[ "$assigned_ip" == "$lb_ip" ]] && break
  sleep 5
done
[[ "${assigned_ip:-}" == "$lb_ip" ]] || { echo "Ingress LB did not acquire the reserved IP ($lb_ip); DNS was not changed" >&2; exit 1; }

# This second apply only adds new application names. Existing DNS names remain untouched.
terraform -chdir="$project_root/cluster" apply -var='create_app_dns_records=true'
echo "Ingress LB: $lb_ip"
echo "DNS records created. Install app workloads, ingress routes and TLS before use."
