# DGOM Scaleway replacement environment

Run `./deploy.sh` from this directory for the infrastructure sequence. It creates a new VPC, `10.80.0.0/22` Private Network, NAT Public Gateway, Kapsule 1.37.0 with two private GP1-XS workers, a reserved public LB IP, an Object Storage bucket for CNPG backups, Traefik ingress and four new DNS A records in the existing zone. The ingress Service creates and maintains the actual Scaleway LB and worker backends. It does **not** provision Keycloak, n8n, Grist, Superset, CNPG operator, app routes or TLS: see the application checklist below.

## Before running

1. Copy `cluster/terraform.tfvars.example` to `cluster/terraform.tfvars`. Check bucket name uniqueness and confirm `10.80.0.0/22` does not overlap VPN, on-premises or other future peering routes. The old `10.0.0.0/28` does not overlap it.
2. Set up a new remote Terraform state for `cluster/`. Do not reuse the old GitLab state named `dgom`. This root defaults to local state until a backend is configured. Keep Scaleway credentials out of source control.
3. Confirm the new DNS labels `keycloak.dgom`, `n8n.dgom`, `grist.dgom`, `superset.dgom` do not already exist. Existing `auth.dgom`, `dgom`, and `sastudio.dgom` belong to the old state and are not changed by this project. DNS permissions must include the existing `sdan-ccp.numerique-interieur.fr` zone.
4. Install `terraform`, `scw`, `kubectl`, and `helm`; authenticate `scw` and export `SCW_ACCESS_KEY` and `SCW_SECRET_KEY` for Terraform. Ensure the API identity can create VPC, Kapsule, LB IP, bucket and DNS resources.
5. Run `terraform -chdir=cluster init` and `terraform -chdir=cluster plan -var='create_app_dns_records=false'` to review infrastructure. Run `./deploy.sh` to apply infrastructure, install Traefik, verify that the LB has the reserved IP, and create the DNS records in one invocation. Leave `create_app_dns_records` out of tfvars: the script sets it for each phase. Terraform will ask for confirmation for each of its two phases. If the ingress install fails, DNS is not created; rerun the script after fixing it.

The new LB uses a **new** IP. Traffic on existing `51.15.210.251` remains on the old LB. The new DNS names point at the new IP after the script finishes; until the app workloads, ingress routes and certificates are installed, their URLs will return a missing route or TLS error. The public gateway IP is for outbound traffic from private nodes, not for DNS.

## CNPG backup setup

The bucket is created with `force_destroy = false` and Terraform `prevent_destroy`. Bucket creation alone does not cause backups. Install a version-pinned CloudNativePG operator and the Barman Cloud CNPG-I plugin, then create a least-privilege S3-compatible access key with access to this bucket. Store the access key in a Kubernetes Secret named `cnpg-s3` with keys `ACCESS_KEY_ID` and `ACCESS_SECRET_KEY` in namespace `dgom` using your approved secret delivery method. Replace `BUCKET_NAME` in `k8s/cnpg-backup.yaml.example` with `terraform -chdir=cluster output -raw cnpg_backup_bucket`, review the manifest, and apply it. It defines a single PostgreSQL instance with a 100 Gi volume, WAL archiving and a daily backup schedule. Verify a backup object and perform a restore test. Scale to multiple instances for database availability if needed.

The `k8s/namespace-storage.yaml` file creates the namespace and 20 Gi claims for each application. It does not create a separate PostgreSQL PVC because CNPG creates its own. Check the default CSI StorageClass and whether individual apps actually require their claims.

## Application checklist

- Install application images/charts with chosen versions and inject their secrets securely. Set up databases/users in CNPG and the app-specific configuration.
- Create Traefik Ingress objects for `keycloak.dgom`, `n8n.dgom`, `grist.dgom`, and `superset.dgom` with Services/ports matching the installed applications. Configure a TLS solution (cert-manager DNS-01 with authorized DNS access, or an organization-managed wildcard certificate). The new DNS records alone do not configure routes or TLS.
- Preserve old `auth.dgom`, `dgom`, and `sastudio.dgom` until dependent applications are migrated. The old Terraform root owns those records; a blanket old-state `terraform destroy` would delete them. Move their state ownership or remove only their old state bindings after recording IDs, while leaving the remote DNS records in place.
- Check backup restores, application health and DNS before retiring the old LB or any data. The existing `51.15.210.251` address is not transferred by this project.
